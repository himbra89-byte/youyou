export interface Generator {
  generate(): Promise<void>
}
