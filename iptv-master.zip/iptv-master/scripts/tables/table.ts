export interface Table {
  create(): void
}
